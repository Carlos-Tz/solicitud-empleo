<?php

namespace Database\Seeders;
use Faker\Factory as Faker;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        /* $faker = Faker::create();

        $gender = $faker->randomElement(['male', 'female']);

    	foreach (range(1,200) as $index) {
            DB ::table('customers')->insert([
                'name' => $faker->name($gender),
                'type' => 1,
                'rpu' => '',
                'alias' => '',
                'street' => $faker->address,
                'ext_num' => $faker->numberBetween($min = 100, $max = 9000),
                'int_num' => '',
                'colony' => $faker->word,
                'city' => $faker->word,
                'state' => 'Colima',
                'country' => 'México',
                'pc' => $faker->numberBetween($min = 10000, $max = 90000),
                'tel' => $faker->phoneNumber,
                'email' => $faker->email,
                'name_contact' => $faker->name($gender),
                'tel_contact' => $faker->phoneNumber,
                'email_contact' => $faker->email,
                'lim_credit' => '',
                'id_user' => 1,
                'status' => 1,
                'comments' => '',
                'date_project' => $faker->date($format = 'd/m/Y', $max = 'now'),
                'sat_invoice' => 1,
                'sat_tax_reg' => 1,
                'sat_bussi_name' => '',
                'sat_address' => '',
                'sat_rfc' => '',
                'sat_email' => $faker->email,
                'sat_cfdi' => 1,
                'sat_way_pay' => 1,
                'sat_descrip' => '',
            ]);
        } */
    }
}
