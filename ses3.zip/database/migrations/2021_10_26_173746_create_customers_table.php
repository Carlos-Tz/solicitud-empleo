<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100)->unique();
            $table->tinyInteger('type');
            $table->string('rpu', 15)->nullable();
            $table->string('alias', 50)->nullable();
            $table->string('street', 100);
            $table->string('ext_num', 8);
            $table->string('int_num', 8)->nullable();
            $table->string('colony', 100);
            $table->string('city', 50);
            $table->string('state', 30);
            $table->string('country', 30);
            $table->integer('pc');
            $table->string('tel', 15)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('name_contact', 100);
            $table->string('tel_contact', 15)->unique();
            $table->string('email_contact', 100)->nullable();
            $table->decimal('lim_credit', 10, 2)->nullable();
            $table->bigInteger('id_user');
            $table->string('status', 50);
            $table->string('comments', 100)->nullable();
            $table->date('date_project');
            $table->tinyInteger('sat_invoice');
            $table->string('sat_tax_reg', 50);
            $table->string('sat_bussi_name', 100)->nullable();
            $table->string('sat_address', 250)->nullable();
            $table->string('sat_rfc', 13)->nullable();
            $table->string('sat_email', 100)->nullable();
            $table->tinyInteger('sat_cfdi');
            $table->tinyInteger('sat_way_pay');
            $table->string('sat_descrip', 255)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
