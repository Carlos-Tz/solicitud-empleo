@extends('layouts.app')

@section('content')

@include('layouts.includes.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">    
                        <h4 class="card-title">{{ __('Registrar Usuario') }}</h4>                      
                            <form method="POST" action="{{ route('users.store') }}" id="registerForm">
                                @csrf
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="first_name">{{ __('Nombre(s)') }}</label>
                                                <div class="col-sm-9">
                                                    <input id="first_name" type="text" class="form-control @error('first_name') is-invalid @enderror" name="first_name" value="{{ old('first_name') }}" required autocomplete="first_name" placeholder="Nombre(s)" autofocus>

                                                    @error('first_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="last_name">{{ __('Apellidos') }}</label>
                                                <div class="col-sm-9">
                                                    <input id="last_name" type="text" class="form-control @error('last_name') is-invalid @enderror" name="last_name" value="{{ old('last_name') }}" required autocomplete="last_name" placeholder="Apellidos">

                                                    @error('last_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="username">{{ __('Usuario') }}</label>
                                                <div class="col-sm-9">
                                                    <input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}" required autocomplete="username" placeholder="Usuario">

                                                    @error('username')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="email">{{ __('Correo') }}</label>
                                                <div class="col-sm-9">
                                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="example@email.com">

                                                    @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 " for="role">{{ __('Tipo de usuario') }}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="role" name="role">
                                                        <!-- <option value="1" selected>Administrador</option> -->
                                                        @foreach ($roles as $key => $role)
                                                            @if ($key > 0)
                                                            <option value="{{$role->id}}">{{ $role->name }}</option>
                                                            @endif
                                                        @endforeach
                                                        <!-- <option value="2" selected>Sistemas</option>
                                                        <option value="3">Ejecutivo ventas</option>
                                                        <option value="4">Contabilidad</option>
                                                        <option value="5">Compras</option>
                                                        <option value="6">RH</option>
                                                        <option value="7">Innovación y desarrollo</option>
                                                        <option value="8">JCF</option> -->
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 " for="movements">{{ __('Movimientos') }}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="movements" name="movements">
                                                        <option value="Ver mis movimientos" selected>Ver mis movimientos</option>
                                                        <option value="Ver todos">Ver todos</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 " for="status">{{ __('Estatus') }}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="status" name="status">
                                                        <option value="1" selected>Activo</option>
                                                        <option value="2">Inactivo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="img_user">{{ __('Foto')}}</label>
                                                <div class="col-sm-9">
                                                    <input type="file" name="img_user" id="img_user" class="file-upload-default">
                                                    <div class="input-group col-xs-12">
                                                        <input type="text" class="form-control file-upload-info" disabled placeholder="Cargar foto">
                                                        <span class="input-group-append">
                                                            <button class="file-upload-browse btn btn-sm btn-success" type="button">Cargar</button>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="password">{{ __('Password') }}</label>
                                                <div class="col-sm-9">
                                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" value="{{ old('password') }}" required autocomplete="password" placeholder="********">

                                                    @error('password')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-check form-check-flat form-check-primary">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input">
                                            Recuerdame
                                        </label>
                                    </div>

                                    <a type="button" class="btn btn-secondary" href="{{ route('users.index') }}">Cancelar</a>
                                    <button type="submit" class="btn btn-success me-2">{{ __('Guardar') }}</button>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection