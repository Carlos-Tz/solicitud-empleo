@extends('layouts.app')

@section('content')

@include('layouts.includes.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-start">
                            <div>
                                <h4 class="card-title card-title-dash">Usuarios</h4>
                            </div>
                            {{-- <div>
                                <form class="search-form" action="#">                                    
                                    <input type="text" class="form-control" placeholder="Buscar" id="search" name="search">
                                </form>
                            </div> --}}
                            @hasanyrole('system|admin')
                            <div>
                                <a class="btn btn-success text-white mb-0 me-0" type="button" href="{{ route('users.create') }}" style="padding: 0.4rem 1.5rem;">
                                    <i class="mdi mdi-account-plus"></i>
                                    Nuevo Usuario
                                </a>
                            </div>
                            @endhasanyrole
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped" id="users-datatable">
                                <thead>
                                    <tr>
                                        <th>Usuario</th>
                                        <th>Nombre</th>
                                        <th>Apellidos</th>
                                        <th>Tipo de usuario</th>
                                        <th>Estatus</th>
                                        <th>Opciones</th>
                                    </tr>
                                </thead>
                                <tbody>                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        {{-- {{ $users->links()}} --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('layouts.includes.footer')
</div>
<script type="text/javascript">
    var dataTable = $('#users-datatable').DataTable({
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        processing: true,
        serverSide: true,
        order: [],
        searchDelay: 500,
        "scrollX": "auto",
        "responsive": true,
        // "lengthChange": false,
        "autoWidth": true,
        ajax: {
            url: '{{ route("users.list") }}',
            type: 'post',
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          data: function (data) {
                // data.fromValues = $("#filterUserType").serialize();
            },
        },
        columns: [
           /*  {data: 'id', name: 'id'}, */
            {data: 'username', name: 'username'},
            {data: 'first_name', name: 'first_name'},
            {data: 'last_name', name: 'last_name'},
            {data: 'role', name: 'role'},
            {data: 'status', name: 'status'},
            {data: 'action', name: 'action', searchable: false, sortable: false},
        ],
    });
  </script>
@endsection