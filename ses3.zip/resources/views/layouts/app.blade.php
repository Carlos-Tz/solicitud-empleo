<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'SES') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <!-- plugins:js -->
    <!-- <script src="{{ asset('css/vendors/js/vendor.bundle.base.js') }}"></script> -->
    <script src="{{ asset('js/vendors/jquery.min.js') }}"></script>
    {{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> --}}
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script> --}}
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="{{ asset('js/vendors/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('js/vendors/perfect-scrollbar.min.js') }}"></script>
    {{-- <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script> --}}
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="{{ asset('js/vendors/chart.js/Chart.min.js') }}"></script>
    <!-- <script src="{{ asset('css/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js') }}" src="vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script> -->
    <script src="{{ asset('js/vendors/progressbar.js/progressbar.min.js') }}"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="{{ asset('js/vendors/off-canvas.js') }}"></script>
    <script src="{{ asset('js/vendors/hoverable-collapse.js') }}"></script>
    <script src="{{ asset('js/vendors/template.js') }}"></script>
    <script src="{{ asset('js/vendors/settings.js') }}"></script>
    <script src="{{ asset('js/vendors/todolist.js') }}"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="{{ asset('js/vendors/dashboard.js') }}"></script>
    <script src="{{ asset('js/vendors/Chart.roundedBarCharts.js') }}"></script>
    <!-- End custom js for this page-->

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <!-- plugins:css -->
    <link href="{{ asset('css/vendors/feather/feather.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/mdi/css/materialdesignicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/ti-icons/css/themify-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/typicons/typicons.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/simple-line-icons/css/simple-line-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/css/vendor.bundle.base.css') }}" rel="stylesheet">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    {{-- <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet"> --}}
    <link href="{{ asset('css/vendors/dataTables.bootstrap4.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/select.dataTables.min.css') }}" rel="stylesheet">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link href="{{ asset('css/vertical-layout-light/style.css') }}" rel="stylesheet">
    <!-- endinject -->
</head>

<body>
    <div id="app" class="container-scroller">

        @include('layouts.includes.navbar')

        <main class="container-fluid page-body-wrapper">
            @yield('content')
        </main>
    </div>
    <script>
        $(function () {
            setInterval(function checkSession() {
                $.get('/is-logged-in');/* , function (data)  {*/
                    //if session was expired
                    /* console.log('check!!');
                    if (!data.isLoggedIn){ */
                        //redirect to login page or, may be better, just reload page
                      /*   location.reload();   
                                             
                    }
                }); */
            }, 20000);
        });
    </script>
</body>

</html>