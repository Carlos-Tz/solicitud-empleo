@extends('layouts.app')

@section('content')

@include('layouts.includes.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">    
                        <h4 class="card-title">{{ __('Crear Prospecto') }}</h4>                      
                            <form method="POST" action="{{ route('customers.store') }}">
                                @csrf                                                                                          
                                <ul class="nav nav-tabs border-top" id="setting-panel" role="tablist">
                                  <li class="nav-item">
                                    <a class="nav-link active" id="todo-tab" data-bs-toggle="tab" href="#personal_data" role="tab" aria-controls="personal_data" aria-expanded="true">Datos Personales</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" id="chats-tab" data-bs-toggle="tab" href="#billing_data" role="tab" aria-controls="billing_data">Datos Facturación</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" id="chats-tab" data-bs-toggle="tab" href="#extra_data" role="tab" aria-controls="extra_data">Extras</a>
                                  </li>
                                </ul>
                                <div class="tab-content" id="setting-content">
                                  <div class="tab-pane fade show active scroll-wrapper" id="personal_data" role="tabpanel" aria-labelledby="personal_data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="name">{{ __('Nombre completo*')}} <small>{{ __('igual que en recibo')}}</small></label>
                                                <div class="col-sm-9">
                                                    <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" placeholder="nombre" autofocus>

                                                    @error('name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="type">{{ __('Tipo')}}</label>
                                                <div class="col-sm-7">
                                                    <select class="form-control" id="type" name="type">
                                                        <option value="1" selected>Prospecto</option>
                                                        <option value="2">Cliente</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="status">{{ __('Estatus')}}</label>
                                                <div class="col-sm-7">
                                                    <select class="form-control" id="status" name="status">
                                                        <option value="1" selected>Nuevo</option>
                                                        <option value="2">Visita</option>
                                                        <option value="3">Cotización</option>
                                                        <option value="4">Ganado</option>
                                                        <option value="5">Firma Contrato</option>
                                                        <option value="6">Perdido</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="alias">{{ __('Alias')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="alias" type="text" class="form-control @error('alias') is-invalid @enderror" name="alias" value="{{ old('alias') }}" autocomplete="alias" placeholder="alias">

                                                    @error('alias')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="ejecutive">{{ __('Ejecutivo')}}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control">
                                                        <option value="{{ Auth::user()->role }}" selected> {{ Auth::user()->first_name }} {{ Auth::user()->last_name }} </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="street">{{ __('Calle*')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="street" type="text" class="form-control @error('street') is-invalid @enderror" name="street" value="{{ old('street') }}" autocomplete="street" required placeholder="calle">

                                                    @error('street')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="ext_num">{{ __('Num. ext.*')}}</label>
                                                <div class="col-sm-7">
                                                    <input id="ext_num" type="text" class="form-control @error('ext_num') is-invalid @enderror" name="ext_num" value="{{ old('ext_num') }}" autocomplete="ext_num" required placeholder="num. ext">

                                                    @error('ext_num')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="int_num">{{ __('Num. int.')}}</label>
                                                <div class="col-sm-7">
                                                    <input id="int_num" type="text" class="form-control @error('int_num') is-invalid @enderror" name="int_num" value="{{ old('int_num') }}" autocomplete="int_num" placeholder="num. int">

                                                    @error('int_num')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="colony">{{ __('Colonia*')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="colony" type="text" class="form-control @error('colony') is-invalid @enderror" name="colony" value="{{ old('colony') }}" autocomplete="colony" required placeholder="colonia">

                                                    @error('colony')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="city">{{ __('Municipio*')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="city" type="text" class="form-control @error('city') is-invalid @enderror" name="city" value="{{ old('city') }}" autocomplete="city" required placeholder="municipio">

                                                    @error('city')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="state">{{ __('Estado*')}}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="state" name="state">
                                                        @foreach ($states as $item)
                                                            <option value="{{ $item }}">{{ $item }}</option>                                                    
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="country">{{ __('País*')}}</label>
                                                <div class="col-sm-7">
                                                    <select class="form-control" name="country" id="country">
                                                        <option value="México">MÉXICO</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label class="col-sm-5" for="pc">{{ __('C.P.*')}}</label>
                                                <div class="col-sm-7">
                                                    <input id="pc" type="number" class="form-control @error('pc') is-invalid @enderror" name="pc" value="{{ old('pc') }}" autocomplete="pc" required placeholder="C.P.">

                                                    @error('pc')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="tel">{{ __('Teléfono oficina')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="tel" type="text" class="form-control @error('tel') is-invalid @enderror" name="tel" value="{{ old('tel') }}" autocomplete="tel" placeholder="teléfono">

                                                    @error('tel')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="email">{{ __('Correo oficina')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email" placeholder="correo">

                                                    @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="name_contact">{{ __('Contacto nombre*')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="name_contact" type="text" class="form-control @error('name_contact') is-invalid @enderror" name="name_contact" value="{{ old('name_contact') }}" required autocomplete="name_contact" placeholder="nombre">

                                                    @error('name_contact')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="tel_contact">{{ __('Contacto teléfono*')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="tel_contact" type="text" class="form-control @error('tel_contact') is-invalid @enderror" name="tel_contact" value="{{ old('tel_contact') }}" autocomplete="tel_contact" required placeholder="teléfono">

                                                    @error('tel_contact')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="email_contact">{{ __('Contacto correo')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="email_contact" type="email" class="form-control @error('email_contact') is-invalid @enderror" name="email_contact" value="{{ old('email_contact') }}" autocomplete="email_contact" placeholder="correo">

                                                    @error('email_contact')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="lim_credit">{{ __('Lim. Crédito')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="lim_credit" type="number" class="form-control @error('lim_credit') is-invalid @enderror" name="lim_credit" value="{{ old('lim_credit') }}" autocomplete="lim_credit"  placeholder="lim. crédito">

                                                    @error('lim_credit')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                  </div>
                                  <div class="tab-pane fade scroll-wrapper" id="billing_data" role="tabpanel" aria-labelledby="billing_data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-4" for="sat_invoice">{{ __('¿Requiere factura?')}}</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control" id="sat_invoice" name="sat_invoice">
                                                        <option value="1" selected>Si</option>
                                                        <option value="2">No</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_tax_reg">{{ __('Regimen fiscal')}}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="sat_tax_reg" name="sat_tax_reg">
                                                        <option value="1" selected>616 Sin obligaciones fiscales</option>
                                                        <option value="2">612 Personas físicas con actividades empresariales y profesionales</option>
                                                        <option value="3">601 General de ley personas morales</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_bussi_name">{{ __('Razón social')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="sat_bussi_name" type="text" class="form-control @error('sat_bussi_name') is-invalid @enderror" name="sat_bussi_name" value="{{ old('sat_bussi_name') }}" autocomplete="sat_bussi_name" placeholder="razón social">

                                                    @error('sat_bussi_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_address">{{ __('Domicilio')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="sat_address" type="text" class="form-control @error('sat_address') is-invalid @enderror" name="sat_address" value="{{ old('sat_address') }}" autocomplete="sat_address" placeholder="domicilio">

                                                    @error('sat_address')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_rfc">{{ __('RFC')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="sat_rfc" type="text" class="form-control @error('sat_rfc') is-invalid @enderror" name="sat_rfc" value="{{ old('sat_rfc') }}" autocomplete="sat_rfc" placeholder="rfc">

                                                    @error('sat_rfc')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_email">{{ __('Correo')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="sat_email" type="email" class="form-control @error('sat_email') is-invalid @enderror" name="sat_email" value="{{ old('sat_email') }}" autocomplete="sat_email" placeholder="correo">

                                                    @error('sat_email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_cfdi">{{ __('Uso del CFDI')}}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="sat_cfdi" name="sat_cfdi">
                                                        <option value="1" selected>P01-Por definir</option>
                                                        <option value="2">G01-Adquisición de mercancías</option>
                                                        <option value="3">G03-Gastos en general</option>
                                                        <option value="4">I01-Construcciones</option>
                                                        <option value="5">I02-Mobiliario y equipo de oficina por inversiones</option>
                                                        <option value="6">I04-Equipo de cómputo y accesorios</option>
                                                        <option value="7">I05-Dados, troqueles, moldes, matrices y herramental</option>
                                                        <option value="8">I06-Comunicaciones telefónicas</option>
                                                        <option value="9">I08-Otra maquinaria y equipo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_way_pay">{{ __('Forma de pago')}}</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="sat_way_pay" name="sat_way_pay">
                                                        <option value="1" selected>01 Efectivo</option>
                                                        <option value="2">02 Cheque nominativo</option>
                                                        <option value="3">03 Transferencia</option>
                                                        <option value="4">04 Tarjeta de crédito</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="sat_descrip">{{ __('Descripción del producto ó servicio')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="sat_descrip" type="text" class="form-control @error('sat_descrip') is-invalid @enderror" name="sat_descrip" value="{{ old('sat_descrip') }}" autocomplete="sat_descrip" placeholder="descripción">

                                                    @error('sat_descrip')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="tab-pane fade scroll-wrapper" id="extra_data" role="tabpanel" aria-labelledby="extra_data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="date_project">{{ __('Fecha proyecto')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="date_project" type="date" class="form-control @error('date_project') is-invalid @enderror" name="date_project" value="{{ old('date_project') }}" required>

                                                    @error('date_project')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3" for="rpu">{{ __('RPU')}}</label>
                                                <div class="col-sm-9">
                                                    <input id="rpu" type="text" class="form-control @error('rpu') is-invalid @enderror" name="rpu" value="{{ old('rpu') }}" autocomplete="rpu" placeholder="285980303220">

                                                    @error('rpu')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <label class="col-sm-2" for="comments">{{ __('Comentarios')}}</label>
                                                <div class="col-sm-10">
                                                    <input id="comments" type="text" class="form-control @error('comments') is-invalid @enderror" name="comments" value="{{ old('comments') }}" autocomplete="comments" placeholder="comentarios">

                                                    @error('comments')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                                <a type="button" class="btn btn-secondary" href="{{ route('customers.index') }}">Cancelar</a>
                                <button type="submit" class="btn btn-success me-2">{{ __('Guardar') }}</button>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@if (Auth::user())
<script>
    $('#date_project').val(new Date().toISOString().slice(0, 10));   
</script>
@endif

@endsection