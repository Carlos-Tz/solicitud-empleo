<ul class="navbar-nav">
    <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
        <h1 class="welcome-text">Bienvenido <span class="text-black fw-bold">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}!</span></h1>
        <!-- <h3 class="welcome-sub-text">Your performance summary this week </h3> -->
    </li>
</ul>