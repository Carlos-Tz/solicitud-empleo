<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">

        <!-- Include menu button -->
        @auth
        @include('layouts.includes.buttonMenu')
        @else
        <div class="me-3"></div>
        @endauth

        <div>
            <a class="navbar-brand brand-logo" href="{{ url('/') }}">
                <img src="{{ asset('/images/logo_ses.png') }}" alt="logo" />
            </a>
            <a class="navbar-brand brand-logo-mini" href="{{ url('/') }}">
                <img src="{{ asset('/images/logo_ses.png') }}" alt="logo" />
            </a>
        </div>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-top">

        <!-- Include header welcome message -->
        @auth
        @include('layouts.includes.welcomeMessage')
        @endauth
        <ul class="navbar-nav ms-auto">
            @auth
            <li class="nav-item dropdown d-none d-lg-block user-dropdown">
                <a class="nav-link" id="UserDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="mdi mdi-account-settings" style="font-size: 1.5rem;"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                    <div class="dropdown-header text-center">
                        <img class="img-md rounded-circle" src="{{ asset('/images/profile.jpg') }}" alt="Profile image">
                        <p class="mb-1 mt-3 font-weight-semibold">{{ Auth::user()->username }}</p>
                        <p class="fw-light text-muted mb-0">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }} </p>
                        <p class="fw-light text-muted mb-0">{{ Auth::user()->email }}</p>
                    </div>
                    <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                        <i class="dropdown-item-icon mdi mdi-power text-primary me-2"></i>
                        {{ __('Salir') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                </div>
            </li>
            @else
            @if (Route::has('login'))
            <li class="nav-item">
                <a class="nav-link" href="{{ route('login') }}">
                    {{ __('Login') }}
                    <i class="dropdown-item-icon mdi mdi-login text-primary me-2"></i>
                </a>
            </li>
            @endif

            @if (Route::has('register'))
            <li class="nav-item">
                <a class="nav-link" href="{{ route('register') }}">
                    {{ __('Register') }}
                    <i class="dropdown-item-icon mdi mdi-account-plus text-primary me-2"></i>
                </a>
            </li>
            @endif
            @endauth
        </ul>
        <!-- Include right menu button -->
        @auth
        @include('layouts.includes.buttonRightMenu')
        @endauth
    </div>
</nav>