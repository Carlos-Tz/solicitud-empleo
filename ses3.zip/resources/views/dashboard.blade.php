@extends('layouts.app')

@section('content')

@include('layouts.includes.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                {{ Auth::user() }}
            </div>
        </div>
    </div>
    @include('layouts.includes.footer')
</div>
@endsection