<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
/* 
GET /posts (list all posts) - Only Admin have access
GET /posts/:id (get a post) - Only Admin, Writer, and Subscriber have access
POST /posts (add a new post) - Only Admin and Writer have access
PUT /post/:id (updating a post) - Only Admin and Writer have access
DELETE /posts/:id (delete a post) - Only Admin and Writer have access
POST /users/writer (add a new user with writer scope) - Only Admin have access
POST /users/subscriber (add a new user with subscriber access) - Only Admin have access
DELETE /user/:id (delete a user) - Only Admin have access */

Route::group(['middleware' => 'auth:sanctum'], function() {
    /* // list all posts
    Route::get('posts', [ControllerExample::class, 'post']);
    // get a post
    Route::get('posts/{id}', [ControllerExample::class, 'singlePost']);
    // add a new post
    Route::post('posts', [ControllerExample::class, 'createPost']);
    // updating a post
    Route::put('posts/{id}', [ControllerExample::class, 'updatePost']);
    // delete a post
    Route::delete('posts/{id}', [ControllerExample::class, 'deletePost']); */
    /* Add a new user with System scope */
    Route::post('users/sistemas', [UserController::class, 'createSystem']);
    /* Add a new user with Sales Ejecutive scope */
    Route::post('users/ejecutivo-ventas', [UserController::class, 'createSalesEjecutive']);
    /* Add a new user with Accounting scope */
    Route::post('users/contabilidad', [UserController::class, 'createAccounting']);
    /* Add a new user with Purchasing scope */
    Route::post('users/compras', [UserController::class, 'createPurchasing']);
    /* Add a new user with Purchasing scope */
    Route::post('users/rh', [UserController::class, 'createHumanResource']);
    /* Add a new user with Development scope */
    Route::post('users/desarrollo', [UserController::class, 'createDevelopment']);
    /* Add a new user with JCF scope */
    Route::post('users/jcf', [UserController::class, 'createJCF']);
    /* Delete a user */
    Route::delete('users/{id}', [UserController::class, 'deleteUser']);
});