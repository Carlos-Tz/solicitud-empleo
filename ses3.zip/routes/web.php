<?php

use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Yajra\Datatables\Datatables;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('is-logged-in', function() {
    if (!Auth::check()) {
        return redirect('login');
    }
    /* return response()->json(['isLoggedIn' => Auth::check()]); */
});

/* This serves as the create token page */
Route::get('/intro', function () {
    if (Auth::check() && Auth::user()->role === 1) {
        auth()->user()->createToken('auth_token', ['admin'])->plainTextToken;
    }
    return redirect("/home");
})->middleware('auth');

/* Delete user tokens */
Route::get('clear/token', function () {
    if (Auth::check() && Auth::user()->role === 1) {        
        Auth::user()->tokens()->delete();        
    }
    return redirect("/");;
})->middleware('auth');

Auth::routes();

Route::get('register', [RegisterController ::class, 'showRegistrationForm'])->middleware('restrictothers')->name('register');
Route::post('register', [RegisterController::class, 'register'])->middleware('restrictothers');

Route::get('/home', [HomeController::class, 'index'])->name('home');
//Route::get('users', [UserController::class, 'index'])->name('users');
//Route::post('users', [UserController::class, 'store']);
Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::resources([
    'users' => UserController::class,
    'customers' => CustomerController::class,
]);

Route::post('customers/list', function (Request $request) {
    if ($request->ajax()) {
            $data = Customer::latest()->get();
            return DataTables::of($data)
                ->addIndexColumn()
                ->editColumn('id_user', '{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}')
                ->addColumn('action', function($row){
                    $actionBtn = '<a href="javascript:void(0)" class="edit btn btn-success btn-sm">Edit</a> <a href="javascript:void(0)" class="delete btn btn-danger btn-sm">Delete</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
})->name('customers.list'); 
Route::post('users/list', function (Request $request) {
    if ($request->ajax()) {
            $data = User::latest()->get();
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '<a href="javascript:void(0)" class="edit btn btn-success btn-sm">Edit</a> <a href="javascript:void(0)" class="delete btn btn-danger btn-sm">Delete</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
})->name('users.list'); 
/* Route::get('/post/create', [PostController::class, 'create'])->name('post.create')->middleware('role:admin|system') */
