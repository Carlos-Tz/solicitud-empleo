<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Library\ApiHelpers;
/* use App\Models\Post; */
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{

    use ApiHelpers; // <---- Using the apiHelpers Trait

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /* $users = User::latest()->paginate(10); */
        return view('layouts.users.index'/* , compact('users') */);/* )->with('i', (request()->input('page', 1) - 1) * 5); */
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $role = $request->input('role');
        $validatedData = $request->validate($this->userValidatedRules());
        $validatedData['password'] = Hash::make($validatedData['password']);
        $validatedData['img_user'] = '';
        $validatedData['id_type_user'] = '2';
        // Create New User 
        $user = User::create($validatedData);
        switch ($role) {
            case 1:
                $user->assignRole('admin');
                break;
            case 2:
                $user->assignRole('system');
                break;
            case 3:
                $user->assignRole('salesEjecutive');
                break;
            case 4:
                $user->assignRole('accounting');
                break;
            case 5:
                $user->assignRole('purchasing');
                break;
            case 6:
                $user->assignRole('hr');
                break;
            case 7:
                $user->assignRole('innovation');
                break;
            case 8:
                $user->assignRole('jcf');
                break;
            default:
                $user->assignRole('user');
                break;
        }
        return redirect()->route('users.index')->with('Success', 'User created successfully!');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $roles = Role::all();
        return view('layouts.users.create', compact('roles'));
    }


    /* This checks if the user authorizing as an Admin or Writer or Subscriber token ability, if so, we return the specified post the user is requesting. If the post is not found, we return a 404 error. */
    /* public function singlePost(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user) || $this->isWriter($user) || $this->isSubscriber($user)) {
            $post = DB::table('posts')->where('id', $id)->first();
            if (!empty($post)) {
                return $this->onSuccess($post, 'Post Retrieved');
            }
            return $this->onError(404, 'Post Not Found');
        }
        return $this->onError(401, 'Unauthorized Access');
    } */

    /* We only want to give Admin and Writer access to create a post, so, we check if the requesting user has the both abilities, if so, we do some validation, if validation passes, we create the Post, if it fails, we return an error. If the user authorizing doesn't have the ability we are requiring, we return an Unauthorized error. */
    /* public function createPost(Request $request): JsonResponse
    {

        $user = $request->user();
        if ($this->isAdmin($user) || $this->isWriter($user)) {
            $validator = Validator::make($request->all(), $this->postValidationRules());
            if ($validator->passes()) {
                // Create New Post
                $post = new Post();
                $post->title = $request->input('title');
                $post->slug = Str::slug($request->input('title'));
                $post->content = $request->input('content');
                $post->save();

                return $this->onSuccess($post, 'Post Created');
            }
            return $this->onError(400, $validator->errors());
        }

        return $this->onError(401, 'Unauthorized Access');

    } */

    /* This is similar to the createPost method except that we are simply updating the Post data. */
    /* public function updatePost(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user) || $this->isWriter($user)) {
            $validator = Validator::make($request->all(), $this->postValidationRules());
            if ($validator->passes()) {
                // Create New Post
                $post = Post::find($id);
                $post->title = $request->input('title');
                $post->content = $request->input('content');
                $post->save();

                return $this->onSuccess($post, 'Post Updated');
            }
            return $this->onError(400, $validator->errors());
        }

        return $this->onError(401, 'Unauthorized Access');
    } */

    /* This is also similar to the createPost method except this time, we are deleting a Post dat */
    /* public function deletePost(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user) || $this->isWriter($user)) {
            $post = Post::find($id); // Find the id of the post passed
            $post->delete(); // Delete the specific post data
            if (!empty($post)) {
                return $this->onSuccess($post, 'Post Deleted');
            }
            return $this->onError(404, 'Post Not Found');
        }
        return $this->onError(401, 'Unauthorized Access');
    } */

    /* We only want to give Admin access to create a new writer user, so, we check if the request user has the admin ability, if so, we create the user (We are giving the user role 2, admin is role 1, however, this doesn't matter in this case). The most important thing is that as soon as the user is created, we return a token and tag it with the writer ability. */
    /* public function createUserSystem(Request $request): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user)) {
            $validator = Validator::make($request->all(), $this->userValidatedRules());
            if ($validator->passes()) {
                // Create New Writer
                User::create([
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'role' => 2,
                    'password' => Hash::make($request->input('password')),
                ]);

                $writerToken = $user->createToken('auth_token', ['writer'])->plainTextToken;
                return $this->onSuccess($writerToken, 'User Created With Writer Privilege');
            }
            return $this->onError(400, $validator->errors());
        }

        return $this->onError(401, 'Unauthorized Access');

    } */

    /* Similar to the createWriter method, except this time, we tag the token ability a "subscriber". */
    /* public function createSubscriber(Request $request): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user)) {
            $validator = Validator::make($request->all(), $this->userValidatedRules());
            if ($validator->passes()) {
                // Create New Subscriber
                User::create([
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'role' => 3,
                    'password' => Hash::make($request->input('password')),
                ]);

                $writerToken = $user->createToken('auth_token', ['subscriber'])->plainTextToken;
                return $this->onSuccess($writerToken, 'User Created With Subscriber Privilege');
            }
            return $this->onError(400, $validator->errors());
        }

        return $this->onError(401, 'Unauthorized Access');

    } */

    /* This first checks if the user authorizing as an Admin token ability. We restrict the ability to delete the admin user (you can change this) by checking if the role is not set to 1, i f that is true, we delete the user. */
    /*  public function deleteUser(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        if ($this->isAdmin($user)) {
            $user = User::find($id); // Find the id of the post passed
            if ($user->role !== 1) {
                $user->delete(); // Delete the specific user
                if (!empty($user)) {
                    return $this->onSuccess('', 'User Deleted');
                }
                return $this->onError(404, 'User Not Found');
            }
        }
        return $this->onError(401, 'Unauthorized Access');
    }
 */

    /* This checks if the user authorizing as an Admin token ability, if so, we return all created posts. If otherwise, we return an unauthorized error */
    /* public function post(Request $request): JsonResponse
    {
        return $this->onSuccess($request->user()->tokenCan('admin'));
        if ($this->isAdmin($request->user())) {
            $posts = DB::table('posts')->get();
            return $this->onSuccess($posts, 'Posts Retrieved');
        }

        return $this->onError(401, 'Unauthorized Access');
    } */




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /* public function show($id)
    {
        //
    } */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /* public function edit($id)
    {
        //
    } */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /* public function update(Request $request, $id)
    {
        //
    } */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /* public function destroy($id)
    {
        //
    } */
}
