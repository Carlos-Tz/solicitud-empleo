<?php 
namespace App\Http\Library;

use Illuminate\Http\JsonResponse;


trait ApiHelpers
{
    /**
     * Check if token has admin ability
     * @param $user
     * @return bool
     */
    protected function isAdmin($user): bool
    {

        if (!empty($user)){
            return $user->tokenCan('admin');
        }

        return false;

    }

    /**
     * Check if token has writer ability
     * @param $user
     * @return bool
     */
    protected function isWriter($user): bool
    {

        if (!empty($user)){
            return $user->tokenCan('writer');
        }

        return false;

    }

    /**
     * Check if token has subscriber ability
     * @param $user
     * @return false
     */
    protected function isSubscriber($user): bool
    {

        if (!empty($user)){
            return $user->tokenCan('subscriber');
        }

        return false;

    }

    /**
     * @param $data
     * @param string $message
     * @param int $code
     * @return \Illuminate\Http\JsonResponse
     */
    protected function onSuccess($data, string $message = '', int $code = 200): JsonResponse
    {
        return response()->json([
            'status' => $code,
            'message' => $message,
            'data' => $data
        ], $code);
    }

    /**
     * @param int $code
     * @param string $message
     * @return \Illuminate\Http\JsonResponse
     */
    protected function onError( int $code, string $message = ''): JsonResponse
    {
        return response()->json([
            'status' => $code,
            'message' => $message,
        ], $code);
    }

    /**
     * Validation Rules To Be Used When Creating/Updating Post
     * @return string[]
     */
    protected function postValidationRules (): array
    {
        return [
            'title' => 'required|string',
            'content' => 'required|string',
        ];
    }

    /**
     * Validation Rules To Be Used When Creating a User
     * @return string[][]
     */
    protected function userValidatedRules (): array
    {
        return [
            'first_name' => ['required', 'string', 'max:50'],
            'last_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'username' => ['required', 'string', 'min:5','max:50', 'unique:users,username'],
            'password' => ['required', 'string', 'min:8'],
            'role' => ['required'],
            'movements' => ['required'],
            'status' => ['required'],
        ];
    }

    /**
     * Validation Rules To Be Used When Creating a Customer
     * @return string[][]
     */
    protected function customerValidatedRules (): array
    {
        return [
            'name' => ['required', 'string', 'max:100'],
            'type' => ['required'],
            'rpu' => [],
            'alias' => [],
            'street' => ['required', 'string', 'max:100'],
            'ext_num' => ['required', 'string', 'max:8'],
            'int_num' => [],
            'colony' => ['required', 'string', 'max:100'],
            'city' => ['required', 'string', 'max:50'],
            'state' => ['required'],
            'country' => ['required'],
            'pc' => ['required'],
            'tel' => [],
            'email' => [],
            'name_contact' => ['required', 'string', 'max:100'],
            'tel_contact' => ['required', 'string', 'max:15'],
            'email_contact' => [],
            'lim_credit' => [],
            'status' => ['required'],
            'comments' => [],
            'date_project' => ['required'],
            'sat_invoice' => ['required'],
            'sat_tax_reg' => ['required'],
            'sat_bussi_name' => [],
            'sat_address' => [],
            'sat_rfc' => [],
            'sat_email' => [],
            'sat_cfdi' => ['required'],
            'sat_way_pay' => ['required'],
            'sat_descrip' => [],
        ];
    }

    /** 
    *   List of states
    *   @return string[]
    */
    public function getStates(): array
    {
        return [
            "Aguascalientes",
            "Baja California",
            "Baja California Sur",
            "Campeche",
            "Chiapas",
            "Chihuahua",
            "Ciudad de México",
            "Coahuila",
            "Colima",
            "Durango",
            "Guanajuato",
            "Guerrero",
            "Hidalgo",
            "Jalisco",
            "México",
            "Michoacán",
            "Morelos",
            "Nayarit",
            "Nuevo León",
            "Oaxaca",
            "Puebla",
            "Querétaro",
            "Quintana Roo",
            "San Luis Potosí",
            "Sinaloa",
            "Sonora",
            "Tabasco",
            "Tamaulipas",
            "Tlaxcala",
            "Veracruz",
            "Yucatán",
            "Zacatecas"
            ];
    }

}