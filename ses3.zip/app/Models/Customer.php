<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $fillable = [
       'name',
       'type',
       'rpu',
       'alias',
       'street',
       'ext_num',
       'int_num',
       'colony',
       'city',
       'state',
       'country',
       'pc',
       'tel',
       'email',
       'name_contact',
       'tel_contact',
       'email_contact',
       'lim_credit',
       'id_user',
       'status',
       'comments',
       'date_project',
       'sat_invoice',
       'sat_tax_reg',
       'sat_bussi_name',
       'sat_address',
       'sat_rfc',
       'sat_email',
       'sat_cfdi',
       'sat_way_pay',
       'sat_descrip',
    ];
}
