<!-- customers table -->
<table class="table table-striped">
    <thead>
        <tr>
            <th>
                Id
            </th>
            <th>
                Fecha
            </th>
            <th>
                Nombre/Razón Social
            </th>
            <th>
                Tel. Contacto
            </th>
            <th>
                Ejec. venta
            </th>
            <th>
                Estatus
            </th>
            <th>
                Opciones
            </th>
        </tr>
    </thead>
    <tbody>
        @foreach ($customers as $key => $customer)
        <tr>
            <td class="py-1">{{ $key+1 }}</td>
            <td>{{ $customer->date_project }}</td>
            <td>{{ $customer->name }}</td>
            <td>{{ $customer->tel_contact }}</td>
            <td>{{ Auth::user()->username}}</td>
            <td>
                @if ($customer->status == 1)
                {{ __('Nuevo') }}
                @elseif ($customer->status == 2)
                {{ __('Visita') }}
                @elseif ($customer->status == 3)
                {{ __('Cotización') }}
                @elseif ($customer->status == 4)
                {{ __('Ganado') }}
                @elseif ($customer->status == 5)
                {{ __('Firma Contrato') }}
                @elseif ($customer->status == 6)
                {{ __('Perdido') }}
                @endif
            </td>
            <td><i class="mdi mdi-eye"></i></td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- end customers table -->
<!-- users table -->
@foreach ($users as $key => $user)
<tr>
    <td class="py-1">{{ $user->username }}</td>
    <td>{{ $user->first_name }}</td>
    <td>{{ $user->last_name }}</td>
    <td>
        @if ($user->role === 1)
        {{ __('Administrador') }}
        @elseif ($user->role === 2)
        {{ __('Sistemas') }}
        @elseif ($user->role === 3)
        {{ __('Ejecutivo de ventas') }}
        @elseif ($user->role === 4)
        {{ __('Contabilidad') }}
        @elseif ($user->role === 5)
        {{ __('Compras') }}
        @elseif ($user->role === 6)
        {{ __('RH') }}
        @elseif ($user->role === 7)
        {{ __('Innovación y desarrollo') }}
        @elseif ($user->role === 8)
        {{ __('JCF') }}
        @elseif ($user->role === 9)
        {{ __('User') }}
        @endif
    </td>
    <td>
        @if ($user->status === 1)
        {{ __('Activo') }}
        @else
        {{ __('Inactivo') }}
        @endif
    </td>
    <td><i class="mdi mdi-eye"></i></td>
</tr>
@endforeach

<!-- end users table -->